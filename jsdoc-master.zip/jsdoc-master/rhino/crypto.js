'use strict';

module.exports = require('crypto-browserify');
